var mysql = require('mysql2');
var db = mysql.createConnection({
    host : 'db', 
    port: 3306,
    user : 'root', 
    password : 'My19971108!', 
    database : 'new_g-exam', 
});
db.connect();

module.exports = db;