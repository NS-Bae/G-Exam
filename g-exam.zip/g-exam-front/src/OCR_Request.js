import React from 'react';

class OcrRequest  extends React.Component {
  // 새 창 페이지의 기능 및 디자인 구현
  render() {
    return (
      <div>
        <h1>새로 열린 창</h1>
        <p>이 페이지는 새로운 창에서 표시됩니다.</p>
      </div>
    );
  }
}

export default OcrRequest ;